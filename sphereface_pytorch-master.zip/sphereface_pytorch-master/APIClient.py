import requests

def images():
    url = 'http://127.0.0.1:5000/signin'
    files = {'signin': open('test1.jpg', 'rb')}
    multiple_files = [
        ('signin', ('11.png', open('test1.jpg', 'rb'), 'image/jpg')),
        ('signin', ('desktop.png', open('test1.jpg', 'rb'), 'image/png'))
    ]
    headers = {
        'Api-Key':
        'InhpeWFuZzA4MDdJBtx4AWlPpI_Oxx1Ki8',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.98 Safari/537.36'
    }
    # r = requests.post(url, files=multiple_files, headers=headers)
    r = requests.post(url, files=files, headers=headers)
    print(r.text)

images()

