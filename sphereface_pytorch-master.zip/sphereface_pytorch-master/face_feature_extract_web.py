#encoding=utf-8
from __future__ import print_function

import time
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
torch.backends.cudnn.bencmark = True

import os
import sys
import cv2
import random
import datetime
import argparse
import numpy as np
import json
import base64

from dataset import ImageDataset
from matlab_cp2tform import get_similarity_transform_for_cv2
import net_sphere


def alignment(src_img,src_pts):
    ref_pts = [ [30.2946, 51.6963],[65.5318, 51.5014],
        [48.0252, 71.7366],[33.5493, 92.3655],[62.7299, 92.2041] ]
    crop_size = (96, 112)
    src_pts = np.array(src_pts).reshape(5,2)

    s = np.array(src_pts).astype(np.float32)
    r = np.array(ref_pts).astype(np.float32)

    tfm = get_similarity_transform_for_cv2(s, r)
    face_img = cv2.warpAffine(src_img, tfm, crop_size)
    return face_img


starttime = time.time()
print(starttime)
parser = argparse.ArgumentParser(description='PyTorch sphereface lfw')
parser.add_argument('--net','-n', default='sphere20a', type=str)
parser.add_argument('--model','-m', default='model/sphere20a_20171020.pth', type=str)
args = parser.parse_args()

net = getattr(net_sphere,args.net)()
print(args.model)
net.load_state_dict(torch.load(args.model))
net.cuda()
net.eval()
net.feature = True
endt1 = time.time()
print("add model time : ", endt1 - starttime)


# cv2.imdecode和cv2.imread内部都是通过ImageDecoder类来进行图像解码的
# imgs1 = cv2.imread()
# imgs2 = cv2.imread()
# img1 = alignment(cv2.imdecode(np.frombuffer(zfile.read(name1),np.uint8),1),landmark[name1])
# img2 = alignment(cv2.imdecode(np.frombuffer(zfile.read(name2),np.uint8),1),landmark[name2])


from flask import Flask
from flask import request
# from flask import render_template

app = Flask(__name__)


@app.route("/", methods=['POST'])
def get_frame():
    start_time = time.time()
    res = json.loads(request.data)
    #print("res = ", res)
    frame = eval(res["image"].decode("base64"))
    img1 = np.array(frame, dtype=np.uint8)
    cv2.imshow("getimage.jpg", img1)
    cv2.waitKey(30)

    # a = request.get_data()
    #print("a = ", a)
    #imgData1 = base64.b64decode(a)  
    #np_arr1 = np.fromstring(imgData1,np.uint8)
    #img1 = cv2.imdecode(np_arr1,cv2.IMREAD_COLOR)

    landmark = {}
    # with open('data/testlfw_landmark.txt') as f:
    with open('/home/liuyh/IDcar/mxnet_mtcnn_face_detection-master/face_landmark.txt') as f:
        landmark_lines = f.readlines()
    for line in landmark_lines:
        l = line.replace('\n', '').split('\t')
        landmark[l[0]] = [int(k) for k in l[1:]]
    print("landmark : ", landmark)

    f1 = []
    for facenum in range(len(landmark_lines)):
        print(facenum)
        print(landmark[str(facenum)])
        print("src =", img1)
        img1 = alignment(img1, landmark[str(facenum)])
        #imglist = [img1, cv2.flip(img1, 1), img2, cv2.flip(img2, 1)]
        imglist = [img1, cv2.flip(img1, 1)]
        for i in range(len(imglist)):
            imglist[i] = imglist[i].transpose(2, 0, 1).reshape((1, 3, 112, 96))
            imglist[i] = (imglist[i] - 127.5) / 128.0

        img = np.vstack(imglist)
        st1 = time.time()
        img = Variable(torch.from_numpy(img).float(), volatile=True).cuda()
        output = net(img)
        f = output.data
        print(f[0])
        f1.append(f[0].cpu().numpy())
        np.save("faceimg_feature_test/test", f[0].cpu().numpy())
        #with open("f1norm.txt","w") as fn:
        #    fn.write(str(f1.norm()))
        #with open("f1.txt","w") as fa, open("f2.txt","w") as fb:
        #    fa.write(str(f[0]))
        #    fb.write(str(f[2]))
        #print("f1", f1)
        #print("f2", f2)

        #with open("f3.txt","w") as fc:
        #    fc.write(str(f[0]))
        #cosdistance = f1.dot(f2) / (f1.norm() * f2.norm() + 1e-5)
        #print(cosdistance)
        print("all cost time : ", time.time()-start_time)

    return str(f1[0])


if __name__ == "__main__":
    app.run("10.0.201.210", port=8080)  #端口为8081


