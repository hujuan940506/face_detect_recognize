# encoding: utf-8
import urllib
import urllib2
import logging
import ssl
from poster.encode import multipart_encode
from poster.streaminghttp import register_openers
import time

log_file = 'interface_test.log'
logging.basicConfig(filename=log_file, level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')
type = 1
register_openers()
time1=time.time()
#datagen, headers = multipart_encode({"image1": open("testimg/img02.jpg","rb"), "image2": open("testimg/img12.jpg","rb")})#, 'format': 'json'})
datagen, headers = multipart_encode({"username": "image1", "password":"image2"})#, 'format': 'json'})
# datagen, headers = multipart_encode({"taskField": open("config_xml/192.168.56.1_66c221be-6ab2-ef53-1589-fe16877914e2_chk.xml", "rb"),'format':'xml'})
request = urllib2.Request("http://127.0.0.1:5000/signin", datagen, headers)
# request = urllib2.Request("http://www.baidu.com/", datagen, headers)
response = urllib2.urlopen(request).read()
logging.debug('result of task create by configfile:%s' % response)
print("cost times :",time.time()-time1)
print response


