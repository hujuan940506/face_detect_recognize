#coding:utf-8

import requests
url = "http://10.0.201.13:8080/"
str000='img/0001.jpg'
newname = str000.split('/')
print newname[len(newname)-1]
files = {'file':(newname,open('img/0001.jpg','rb'),'image/jpg')}
r = requests.post(url,files = files)
result = r.text
print result
