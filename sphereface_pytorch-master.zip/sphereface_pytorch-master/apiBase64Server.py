#coding:utf-8
from flask import request, Flask
import json
import numpy as np
import time
import cv2

app = Flask(__name__)

@app.route("/", methods=['POST'])
def get_frame():
    start_time = time.time()
    res = json.loads(request.data)
    #print("res = ", res)
    frame1 = eval(res["image1"].decode("base64"))   # dtype为int32
    frame2 = eval(res["image2"].decode("base64"))
    frame1 = np.array(frame1, dtype=np.uint8)
    frame2 = np.array(frame2, dtype=np.uint8)
    cv2.imwrite('upload/tmp1.jpg',frame1)
    cv2.imwrite('upload/tmp2.jpg',frame2)
    duration = time.time() - start_time
    print('duration:[%.0fms]' % (duration*1000))
    return '0000'

if __name__ == "__main__":
    app.run("10.0.201.13", port=8081)  #端口为8081
