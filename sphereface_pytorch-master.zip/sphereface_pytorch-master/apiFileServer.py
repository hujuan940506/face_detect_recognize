#coding:utf-8
from flask import request, Flask
import time
import os
import json
import cv2
app = Flask(__name__)

@app.route("/", methods=['POST'])
def get_frame():
    start_time = time.time()
    upload_file = request.files['file']
    print("upload_file = ", upload_file)
    old_file_name = upload_file.filename
    newname = old_file_name.split(',')[1][:-2][2:]
    # newname = eval(old_file_name)
    print(newname)
    print(type(newname))
    print(newname[1])
    if upload_file:
        file_path = os.path.join('uploadfile/', newname)
        upload_file.save(file_path)
        print("success")
        print('file saved to %s' % file_path)
        print("file_path = ", file_path)
        # img = cv2.imread(file_path)
        # print(img)
        # cv2.imshow("img.jpg", img)
        # cv2.waitKey(0)
        # os.remove(file_path)

        duration = time.time() - start_time
        print('duration:[%.0fms]' % (duration*1000))
        return 'success'
    else:
        return 'failed'


if __name__ == "__main__":
    app.run("10.0.201.13", port=8080)
