#encoding=utf-8
from __future__ import print_function

import time
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
torch.backends.cudnn.bencmark = True

import os
import sys
import cv2
import random
import datetime
import argparse
import numpy as np

from dataset import ImageDataset
from matlab_cp2tform import get_similarity_transform_for_cv2
import net_sphere


def alignment(src_img,src_pts):
    ref_pts = [ [30.2946, 51.6963],[65.5318, 51.5014],
        [48.0252, 71.7366],[33.5493, 92.3655],[62.7299, 92.2041] ]
    crop_size = (96, 112)
    src_pts = np.array(src_pts).reshape(5,2)

    s = np.array(src_pts).astype(np.float32)
    r = np.array(ref_pts).astype(np.float32)

    tfm = get_similarity_transform_for_cv2(s, r)
    face_img = cv2.warpAffine(src_img, tfm, crop_size)
    return face_img


starttime = time.time()
print(starttime)
parser = argparse.ArgumentParser(description='PyTorch sphereface lfw')
parser.add_argument('--net','-n', default='sphere20a', type=str)
parser.add_argument('--model','-m', default='model/sphere20a_20171020.pth', type=str)
args = parser.parse_args()

net = getattr(net_sphere,args.net)()
print(args.model)
net.load_state_dict(torch.load(args.model))
net.cuda()
net.eval()
net.feature = True
endt1 = time.time()
print("add model time : ", endt1 - starttime)


from flask import Flask
from flask import request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    return '<h1>Home</h1>'

@app.route('/signin', methods=['GET'])
def signin_form():
    return '''<form action="/signin" method="post">
              <p><input name="username"></p>
              <p><input name="password" type="password"></p>
              <p><button type="submit">Sign In</button></p>
              </form>'''

@app.route('/signin', methods=['POST'])
def signin():
    # 需要从request对象读取表单内容：
    if request.form['username']=='image1' and request.form['password']=='image2':
        print("image1")
        img1 = cv2.imread('testimg/img02.jpg')
        img2 = cv2.imread('testimg/img12.jpg')

        imglist = [img1, cv2.flip(img1, 1), img2, cv2.flip(img2, 1)]
        for i in range(len(imglist)):
            imglist[i] = imglist[i].transpose(2, 0, 1).reshape((1, 3, 112, 96))
            imglist[i] = (imglist[i] - 127.5) / 128.0

        img = np.vstack(imglist)
        st1 = time.time()
        img = Variable(torch.from_numpy(img).float(), volatile=True).cuda()
        output = net(img)
        f = output.data
        f1, f2 = f[0], f[2]

        cosdistance = f1.dot(f2) / (f1.norm() * f2.norm() + 1e-5)
        print(cosdistance)
        return str(cosdistance)
    return '<h3>Bad username or password.</h3>'

if __name__ == '__main__':
    app.run()
