#encoding=utf-8
from __future__ import print_function

import time
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
torch.backends.cudnn.bencmark = True

import os
import sys
import cv2
import random
import datetime
import argparse
import numpy as np


from dataset import ImageDataset
from matlab_cp2tform import get_similarity_transform_for_cv2
import net_sphere


def alignment(src_img,src_pts):
    ref_pts = [ [30.2946, 51.6963],[65.5318, 51.5014],
        [48.0252, 71.7366],[33.5493, 92.3655],[62.7299, 92.2041] ]
    crop_size = (96, 112)
    src_pts = np.array(src_pts).reshape(5,2)

    s = np.array(src_pts).astype(np.float32)
    r = np.array(ref_pts).astype(np.float32)

    tfm = get_similarity_transform_for_cv2(s, r)
    face_img = cv2.warpAffine(src_img, tfm, crop_size)
    return face_img


starttime = time.time()
print(starttime)
parser = argparse.ArgumentParser(description='PyTorch sphereface lfw')
parser.add_argument('--net','-n', default='sphere20a', type=str)
parser.add_argument('--model','-m', default='model/sphere20a_20171020.pth', type=str)
args = parser.parse_args()

net = getattr(net_sphere,args.net)()
print(args.model)
net.load_state_dict(torch.load(args.model))
net.cuda()
net.eval()
net.feature = True
endt1 = time.time()
print("add model time : ", endt1 - starttime)


landmark = {}
#with open('data/lfw_landmark.txt') as f:
#with open('/home/liuyh/IDcar/mxnet_mtcnn_face_detection-master/real_landmarkminbyhj.txt') as f:
with open('/home/liuyh/IDcar/mxnet_mtcnn_face_detection-master/faceimgtest/preface_landmark.txt') as f:
    landmark_lines = f.readlines()
for line in landmark_lines:
    l = line.replace('\n','').split('\t')
    landmark[l[0]] = [int(k) for k in l[1:]]
#print("landmark : ", landmark)


time11 = time.time()

path = "/home/liuyh/IDcar/mxnet_mtcnn_face_detection-master/faceimgtest"
#fwfea = open('featuretest.txt', 'w')
facei = 0
for root, dirs, files in os.walk(path):
    filepath = root.split('/')
    for file in files:
        if os.path.splitext(file)[1] == '.jpg' or os.path.splitext(file)[1] == '.png' or os.path.splitext(file)[1] == '.jpeg' or os.path.splitext(file)[1] == '.JPG' or os.path.splitext(file)[1] == '.bmp':
            imagename = os.path.join(root, file)
            newname = filepath[-1] + '/' + file
            print(newname)
            print("file = ", os.path.splitext(file)[0])
            print("landmark[name]", landmark[newname])
            img1 = alignment(cv2.imread(imagename), landmark[newname])

            imglist = [img1, cv2.flip(img1, 1)]
            for i in range(len(imglist)):
                imglist[i] = imglist[i].transpose(2, 0, 1).reshape((1, 3, 112, 96))
                imglist[i] = (imglist[i] - 127.5) / 128.0
            #print(imglist)
            img = np.vstack(imglist)
            st1 = time.time()
            img = Variable(torch.from_numpy(img).float(),volatile=True).cuda()
            output = net(img)
            f = output.data
            f1 = f[0]
            #print(f1)
            #fwfea.write(str(f1.cpu().numpy()))
            print("facei = ", facei)
            np.save("faceimg_feature/" + str(os.path.splitext(file)[0]), f1.cpu().numpy())
            #print("featurenumpy = ", f1.cpu().numpy())
            #fwfea.write('\n')
            st2 = time.time()
            print("feature extract time = ", st2-st1)
            facei += 1
#fwfea.close()
            # cosdistance = f1.dot(f2)/(f1.norm()*f2.norm()+1e-5)
            # print("compute time = ", time.time() - st2)




