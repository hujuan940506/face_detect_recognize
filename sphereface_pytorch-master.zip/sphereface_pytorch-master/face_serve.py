#coding=utf-8
from __future__ import print_function
import os
import sys
import re
import cv2
import json
import urllib
import urllib2
import BaseHTTPServer
from SimpleHTTPServer import SimpleHTTPRequestHandler
import SocketServer
import datetime
import shutil
import base64  
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
torch.backends.cudnn.bencmark = True
import random
import argparse
import numpy as np

from dataset import ImageDataset
from matlab_cp2tform import get_similarity_transform_for_cv2
import net_sphere
Handler = SimpleHTTPRequestHandler
Server = BaseHTTPServer.HTTPServer
Protocol = "HTTP/1.0"
port = 8050
server_address = ('10.0.201.13', port)
Handler.protocol_version = Protocol
url = 'http://10.0.201.13/'




parser = argparse.ArgumentParser(description='PyTorch sphereface lfw')
parser.add_argument('--net','-n', default='sphere20a', type=str)
parser.add_argument('--model','-m', default='model/sphere20a_20171020.pth', type=str)
args = parser.parse_args()

net = getattr(net_sphere,args.net)()
net.load_state_dict(torch.load(args.model))
net.cuda()
net.eval()
net.feature = True
def main(test1,test2):
    img1 = cv2.imread(test1)
    img2 = cv2.imread(test2)

    imglist = [img1,cv2.flip(img1,1),img2,cv2.flip(img2,1)]
    for i in range(len(imglist)):
        imglist[i] = imglist[i].transpose(2, 0, 1).reshape((1,3,112,96))
        imglist[i] = (imglist[i]-127.5)/128.0

    img = np.vstack(imglist)
    st1 = time.time()
    img = Variable(torch.from_numpy(img).float(),volatile=True).cuda()
    output = net(img)
    f = output.data
    f1,f2 = f[0],f[2]


    cosdistance = f1.dot(f2)/(f1.norm()*f2.norm()+1e-5)
    return cosdistance
def base64_trans(img_base64,img_name):

    leniyimg=open(img_name+'.jpg','wb')
    single_image = base64.b64decode(img_base64)
    leniyimg.write(single_image)
    leniyimg.close()
    return single_image



class SETHandler(SimpleHTTPRequestHandler):

    def createHTML(self, url, toWrite):

        toWrite = json.dumps(toWrite)

        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.send_header("Content-length", len(toWrite))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(toWrite)

    def do_GET(self):

        self.createHTML()

    def do_POST(self):



        length = int(self.headers.getheader('content-length'))
        qs = self.rfile.read(length)
	qs_root1=qs.split('=')[1]
        
        print (qs)
        base64_trans(qs_root1,'test1')
        #base64_trans(qs_root2,'test2')
        if os.path.exists('test1.jpg'):
            imgdata=cv2.imread('test1.jpg')
           
        

        self.createHTML(url, str(imgdata))
        return qs

Handler = SETHandler
PORT = 4200
httpd = SocketServer.TCPServer(("10.0.201.13", PORT), Handler)
print (" \n serving....... \n")


httpd.serve_forever()
