#encoding=utf-8
from __future__ import print_function

import time
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
torch.backends.cudnn.bencmark = True

import os
import sys
import cv2
import random
import datetime
import argparse
import numpy as np

from dataset import ImageDataset
from matlab_cp2tform import get_similarity_transform_for_cv2
import net_sphere


starttime = time.time()
parser = argparse.ArgumentParser(description='PyTorch sphereface lfw')
parser.add_argument('--net','-n', default='sphere20a', type=str)
parser.add_argument('--model','-m', default='model/sphere20a_20171020.pth', type=str)
args = parser.parse_args()

net = getattr(net_sphere,args.net)()
print(args.model)
net.load_state_dict(torch.load(args.model))
net.cuda()
net.eval()
net.feature = True


img1 = cv2.imread('testimg/img02.jpg')
img2 = cv2.imread('testimg/img12.jpg')

imglist = [img1,cv2.flip(img1,1),img2,cv2.flip(img2,1)]
for i in range(len(imglist)):
    imglist[i] = imglist[i].transpose(2, 0, 1).reshape((1,3,112,96))
    imglist[i] = (imglist[i]-127.5)/128.0

img = np.vstack(imglist)
st1 = time.time()
img = Variable(torch.from_numpy(img).float(),volatile=True).cuda()
output = net(img)
f = output.data
f1,f2 = f[0],f[2]


cosdistance = f1.dot(f2)/(f1.norm()*f2.norm()+1e-5)
print("cosdistance = ", cosdistance)



