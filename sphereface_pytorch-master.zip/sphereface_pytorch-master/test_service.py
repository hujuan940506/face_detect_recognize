#coding=utf-8
import urllib
import httplib
import base64
img1=open('img2142.jpg').read()
aa1=base64.b64encode(img1)
test_data = {"img1":aa1}
print (test_data)
test_data_urlencode = urllib.urlencode(test_data)
requrl = "http://10.0.201.13"
headerdata = {"Host": "10.0.201.13:4200"}

conn = httplib.HTTPConnection("10.0.201.13", 4200)
conn.request(method="POST", url=requrl,
             body=test_data_urlencode, headers=headerdata)
response = conn.getresponse()
res = response.read()
print res
