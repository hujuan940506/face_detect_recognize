#coding:utf-8
import cv2
import json
import requests

img1 = cv2.imread("img/0001.jpg")
img2 = cv2.imread("img/0002.jpg")
res = {"image1": str(img1.tolist()).encode('base64'), "image2": str(img2.tolist()).encode('base64')}  # img是ndarray，无法直接用base64编码，否则会报错
_ = requests.post("http://10.0.201.58:8081", data=json.dumps(res))
