# -*- coding: UTF-8 -*-
import Tkinter as tkinter
from Tkinter import *
import tkFileDialog
import requests
from PIL import Image, ImageTk  
from tkMessageBox import *

import time
import cv2
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
torch.backends.cudnn.bencmark = True

import os
import sys
import cv2
import random
import datetime
import argparse
import numpy as np

from dataset import ImageDataset
from matlab_cp2tform import get_similarity_transform_for_cv2
import net_sphere


starttime = time.time()
parser = argparse.ArgumentParser(description='PyTorch sphereface lfw')
parser.add_argument('--net','-n', default='sphere20a', type=str)
parser.add_argument('--model','-m', default='model/sphere20a_20171020.pth', type=str)
args = parser.parse_args()

net = getattr(net_sphere,args.net)()
print(args.model)
net.load_state_dict(torch.load(args.model))
net.cuda()
net.eval()
net.feature = True
def main(img1,img2):
    imglist = [img1,cv2.flip(img1,1),img2,cv2.flip(img2,1)]
    for i in range(len(imglist)):
        imglist[i] = imglist[i].transpose(2, 0, 1).reshape((1,3,112,96))
        imglist[i] = (imglist[i]-127.5)/128.0

    img = np.vstack(imglist)
    st1 = time.time()
    img = Variable(torch.from_numpy(img).float(),volatile=True).cuda()
    output = net(img)
    f = output.data
    f1,f2 = f[0],f[2]


    cosdistance = f1.dot(f2)/(f1.norm()*f2.norm()+1e-5)
    return cosdistance
def Upload1():
    selectFileName1 = tkFileDialog.askopenfilenames(title='选择文件')#选择文件

    img_open1 = Image.open(selectFileName1[0])  
    image1= ImageTk.PhotoImage(img_open1)
    img_open2 = Image.open(selectFileName1[1])  
    image2= ImageTk.PhotoImage(img_open2)
    img1 = cv2.imread(selectFileName1[0])
    img2 = cv2.imread(selectFileName1[1])
    
    imLabel1=Label(f1,image=image1).grid(row=0, column=0)
    imLabel2=Label(f2,image=image2).grid(row=0, column=1)
    cosdistance=main(img1,img2)
    if cosdistance:
        showerror("Answer", str(cosdistance))
    # canvas1 = Canvas(f1, width = 400 ,height = 400, bg = 'white')
    # rt1=canvas1.create_image(10,0,image = image1,anchor="nw")
    # canvas1.coords(rt1,150,150,200,200)
    # canvas1.pack()    
    f2.mainloop()  
root = Tk()
root.title('Download')  
root.resizable(False, False) 
root.geometry('800x500')
    #设置窗口大小及偏移坐标  
f1 = Frame(root,width=400,height=400,bg='gray',borderwidth=1).grid(row=0, column=0,sticky=N+S)
f2 = Frame(root,width=400,height=400,bg='yellow',borderwidth=1).grid(row=0, column=1,sticky=N+S)
f3 = Frame(root,width=800,height=50,bg='white',borderwidth=1).grid(row=2, column=0,rowspan=1,columnspan=2)
f1_1 = Frame(root,width=400,height=50,bg='white',borderwidth=1).grid(row=1, column=0,rowspan=1,columnspan=2)

# l1 = Label(f1,text='one',bg='pink',width=5).grid(row=0,column=0)



btn1 = Button(f3,text='对比', command=Upload1,height=2,width=7).grid(row=2, column=0,rowspan=1,columnspan=2)

root.mainloop()
# mainloop()
