# coding: utf-8
import mxnet as mx
from mtcnn_detector import MtcnnDetector
import cv2
import os
import time
import argparse
import zipfile
import numpy as np


starttime = time.time()
detector = MtcnnDetector(model_folder='model', ctx=mx.gpu(0), num_worker=4, accurate_landmark=False)
endt = time.time()
print("add model time is :", endt - starttime)

parser = argparse.ArgumentParser(description='mtcnn casia cleaned')
parser.add_argument('--casiacleaned', default='/home/liuyh/dataset/face/casia/CASIAclean.zip', type=str)
args = parser.parse_args()

zfile = zipfile.ZipFile(args.casiacleaned)

path = "/home/liuyh/dataset/face/casia/CASIA-maxpy-clean"

with open('/home/liuyh/IDcar/sphereface_pytorch-master/data/cleaned list.txt') as f:
    landmark_lines = f.readlines()
imgname = []
labels = []
for line in landmark_lines:
    #print("started!")
    #print("line = ", line)

    line = line.replace('\n','').replace('\t','').strip()
    l = line.split(' ')
    #print("l = ", l)
    imgname.append(l[0])
    labels.append(l[1]) 
#print("imgname : ", imgname)
#print("labels = ", labels)

f = open('casiaCleaned_landmark.txt', 'w')
for index,i in enumerate(imgname):
    print("index, i = ", index, i)
    newimgname = "CASIAclean/" + i
    print("newimagename = ", newimgname)
    img = cv2.imdecode(np.frombuffer(zfile.read(newimgname),np.uint8),1)
    #img = cv2.imread(newimgname)
    #print ("img = ", img)
    stime1 = time.time()
    results = detector.detect_face(img)
    stime2 = time.time()
    print("detector one image times :", stime2 - stime1)
    #print(results)
    if results is not None:
        total_boxes = results[0]
        points = results[1]

        print(newimgname)
        print(labels[index])
        # print(points[0][1])
        f.write(
            str(i) + '\t' + str(labels[index])+ '\t' + str(int(round(points[0][0]))) + '\t' + str(int(round(points[0][5]))) + '\t' + str(
                int(round(points[0][1]))) + '\t' + str(int(round(points[0][6])))
            + '\t' + str(int(round(points[0][2]))) + '\t' + str(int(round(points[0][7]))) + '\t' + str(
                int(round(points[0][3]))) + '\t' + str(int(round(points[0][8]))) + '\t' +
            str(int(round(points[0][4]))) + '\t' + str(int(round(points[0][9]))))
        f.write('\n')
f.close()
endtt = time.time()
print("all cost time : ", endtt-endt)


# f = open(path + '/casiaCleaned_landmark.txt', 'w')
# for root, dirs, files in os.walk(path):
#     print("root :", root)
#     filepath = root.split('/')
#     print("filepath[0] = ", filepath[0], filepath[-1])
#     print(dirs)
#     print(files)
#     for file in files:
#         if os.path.splitext(file)[1] == '.jpg' or os.path.splitext(file)[1] == '.png' or os.path.splitext(file)[1] == '.jpeg' or os.path.splitext(file)[1] == '.JPG':
#             #imagename = filepath[-1] + '/' + file
#             imagename = os.path.join(root, file)
#             newname = filepath[-1] + '/' + file
#             print("newname = ", newname)
#             img = cv2.imread(imagename)
#             print(img.shape)
#             w = img.shape[0]
#             h = img.shape[1]
#             if (w>500 and w<1000) or (h>500 and h<1000):
#                 img = cv2.resize(img,(h/3, w/3),interpolation=cv2.INTER_CUBIC)
#             elif (w>1000 and w<1500) or (h>1000 and h<1500):
#                 img = cv2.resize(img,(h/5, w/5),interpolation=cv2.INTER_CUBIC)
#             elif (w>1500 and w<2000) or (h>1500 and h<2000):
#                 img = cv2.resize(img,(h/7, w/7),interpolation=cv2.INTER_CUBIC)
#             elif (w>2000) or (h>2000):
#                 img = cv2.resize(img,(h/9, w/9),interpolation=cv2.INTER_CUBIC)
#             newpath = str('realfaceminmin/' + newname)
#             print("newpath = ", newpath)
#             #print("img = ", img)
#             cv2.imwrite(newpath, img)
#             # run detector
#             stime1 = time.time()
#             results = detector.detect_face(img)
#             stime2 = time.time()
#             print("detector one image times :", stime2-stime1)
#             print(results)
#             if results is not None:
#
#                 total_boxes = results[0]
#                 points = results[1]
#
#                 print(imagename)
#                 #print(points[0][1])
#                 f.write(
#                     str(newname) +'\t' + str(int(round(points[0][0]))) +'\t' + str(int(round(points[0][5]))) +'\t' + str(int(round(points[0][1]))) +'\t' + str(int(round(points[0][6])))
#                     +'\t' + str(int(round(points[0][2]))) +'\t' + str(int(round(points[0][7]))) +'\t' + str(int(round(points[0][3]))) +'\t' + str(int(round(points[0][8]))) +'\t' +
#                     str(int(round(points[0][4]))) +'\t' + str(int(round(points[0][9]))))
#                 f.write('\n')
#
#                 # # extract aligned face chips
#                 # chips = detector.extract_image_chips(img, points, 144, 0.37)
#                 # for i, chip in enumerate(chips):
#                 #     cv2.imshow('chip_' + str(i), chip)
#                 #     cv2.imwrite('chip_' + str(i) + '.png', chip)
#                 #
#                 # draw = img.copy()
#                 # for b in total_boxes:
#                 #     cv2.rectangle(draw, (int(b[0]), int(b[1])), (int(b[2]), int(b[3])), (255, 255, 255))
#                 #
#                 # for p in points:
#                 #     for i in range(5):
#                 #         cv2.circle(draw, (p[i], p[i + 5]), 1, (0, 0, 255), 2)
#                 #
#                 # cv2.imshow("detection result", draw)
#                 # cv2.waitKey(0)
#
#
# f.close()



# --------------
# test on camera
# --------------
'''
camera = cv2.VideoCapture(0)
while True:
    grab, frame = camera.read()
    img = cv2.resize(frame, (320,180))

    t1 = time.time()
    results = detector.detect_face(img)
    print 'time: ',time.time() - t1

    if results is None:
        continue

    total_boxes = results[0]
    points = results[1]

    draw = img.copy()
    for b in total_boxes:
        cv2.rectangle(draw, (int(b[0]), int(b[1])), (int(b[2]), int(b[3])), (255, 255, 255))

    for p in points:
        for i in range(5):
            cv2.circle(draw, (p[i], p[i + 5]), 1, (255, 0, 0), 2)
    cv2.imshow("detection result", draw)
    cv2.waitKey(30)
'''
