# coding: utf-8
import mxnet as mx
from mtcnn_detector import MtcnnDetector
import cv2
import os
import time
import base64
import requests
import json
import numpy as np
from scipy.linalg.misc import norm
import datetime


print("started!")
detector = MtcnnDetector(model_folder='model', ctx=mx.cpu(), num_worker = 4 , accurate_landmark = False)
#print("add detector")
#stim = time.time()
##img = cv2.imread('realfacemin/linyue/0008.jpg')
##img = cv2.imread('faceimgtest/11111.jpg')
#img = cv2.imread('faceimgtest/22222.jpg')

## run detector
#results = detector.detect_face(img)
#print("time:", time.time()-stim)
#print("result:", results)

#starttime = time.time()
#print(starttime)
#if results is not None:

 #   total_boxes = results[0]
 #   points = results[1]
    
 #   # extract aligned face chips
 #   chips = detector.extract_image_chips(img, points, 144, 0.37)
 #   for i, chip in enumerate(chips):
 #       #cv2.imshow('chip_'+str(i), chip)
 #       cv2.imwrite('chip_'+str(i)+'.png', chip)
 #       print('chip_'+str(i)+'.png')

 #   draw = img.copy()
 #   for b in total_boxes:
 #       cv2.rectangle(draw, (int(b[0]), int(b[1])), (int(b[2]), int(b[3])), (255, 255, 255))

 #   for p in points:
 #       for i in range(5):
 #           cv2.circle(draw, (p[i], p[i + 5]), 1, (0, 0, 255), 2)
 #   cv2.imwrite('draw.jpg', draw)
 #   cv2.imshow('draw', draw)
 #   cv2.waitKey(0)
#endtime = time.time()
#print("all cost write time :", endtime - starttime)
#print("all cost time :", endtime - stim)
#    #cv2.imwrite('draw.jpg', draw)
#    #cv2.imshow("detection result", draw)
#    #cv2.waitKey(0)

# --------------
# test on camera
# --------------

camera = cv2.VideoCapture(0)
c = 1

if camera.isOpened(): #判断是否正常打开
    grab, frame = camera.read()
else:
    grab = False

timeF = 3

# while True:
while grab:
    grab, frame = camera.read()
    wpa = "/data2/hujuandata/face_verify_true/"   # 用于保存识别到的人脸图片
    wpa2 = "/data2/hujuandata/face_verify_false/"   # 用于保存识别到的人脸图片
    if (c % timeF == 0):  # 每隔timeF帧进行存储操作
        img = cv2.resize(frame, (320, 240))
        #img = cv2.resize(frame, (640,480))

        t1 = time.time()
        results = detector.detect_face(img)
        #print 'time: ',time.time() - t1

        if results is None:
            cv2.imshow("detection result", img)
            cv2.waitKey(1)
            #grab, frame = camera.read()
            continue

        f = open('face_landmark.txt', 'w')

        total_boxes = results[0]
        points = results[1]

        draw = img.copy()
        for b in total_boxes:
            cv2.rectangle(draw, (int(b[0]), int(b[1])), (int(b[2]), int(b[3])), (255, 255, 255))

        for p in points:
            facenum = 0
            f.write(str(facenum))
            for i in range(5):
                cv2.circle(draw, (p[i], p[i + 5]), 1, (255, 0, 0), 2)
                f.write('\t' + str(int(round(p[i]))) +'\t'+ str(int(round(p[i+5]))))
            f.write('\n')
            facenum += 1
        f.close()
        cv2.imshow("detection result", draw)
        cv2.waitKey(1)


        res = {"image": str(img.tolist()).encode('base64')}
        _ = requests.post("http://10.0.201.210:8080", data=json.dumps(res))
        #print "distance : ", _.text
        #f1 = _.text
        #print("f1 = ", f1)
        #f11 = ( _.text).cpu().numpy()
        f1 = np.load("/home/liuyh/sphereface_pytorch-master/faceimg_feature_test/test.npy")

        preface_path = "/home/liuyh/sphereface_pytorch-master/faceimg_feature"
        for root, dirs, files in os.walk(preface_path):
            filepath = root.split('/')
            #print(len(files))
            d = np.zeros(len(files))
            dictdis = {}
            i = 0
            for file in files:
                #print("file = ",preface_path + "/" + file)
                facei = np.load(preface_path + "/" + file)
                dd = np.dot(f1, facei)/(norm(f1)*norm(facei)+1e-5)
                dictdis[file] = dd
                d[i] = dd
                i += 1
                #print(np.dot(f1, facei)/(norm(f1)*norm(facei)+1e-5))

            #print(d)
            #print(dictdis)
            dictsorted = sorted(dictdis.items(),key = lambda x : x[1], reverse = True)
            print("sorted = ", dictsorted)
            fsorted = dictsorted[0]
            keyd = fsorted[0]
            print("keyd = ", keyd)
            dis = fsorted[1]
            print("dis = ", dis)
            print(float(dis)- 0.5)
            nowTime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            imgn = keyd.split('.')[0]
            if float(dis)- 0.6 > 0:
                #imgn = keyd.split('.')[0]
                wpaa = wpa + imgn + "/"
                print("imgn = ", imgn)
                imgfid = cv2.imread("faceimgtest/" + imgn + ".jpg")
                if not os.path.isdir(wpaa):    # 判断该是否存在该文件夹
                    os.mkdir(wpaa)         # 不存在则新建文件夹
                #nowTime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
                cv2.imwrite(wpaa + nowTime + '_' + str(round(dis,3)) + ".jpg", img)
                cv2.imshow("findimg.jpg", imgfid)
                cv2.waitKey(1)
            else:
                cv2.imwrite(wpa2 + nowTime + '_' + imgn + '_' + str(round(dis,3)) + ".jpg", img)
                
            print("-------------------------------")
        #grab, frame = camera.read()

    c += 1

'''
    base64_data = base64.b64encode(img)
    _ = requests.post("http://10.0.201.210:8080", data=str(base64_data))
    print "distance : ", _.text
'''

